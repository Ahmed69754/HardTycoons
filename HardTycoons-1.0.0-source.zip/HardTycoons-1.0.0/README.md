# HardTycoons 1.0.0

A fresh Fabric client mod project for Minecraft **1.21.4** and **Java 21**.

## Current implementation

- Select a cuboid mining region by looking at blocks and pressing **J** (corner A) and **K** (corner B).
- Press **L** to start/pause the Prison Miner.
- The miner searches the selected region for nearby, non-air, non-liquid, breakable blocks.
- It uses the normal client block-breaking interaction, respects a 5-block distance limit, and does not send custom packets or bypass server protections.
- It pauses when the inventory is full, a screen is open, or the player is in Creative/Spectator.
- Press **Right Shift** for the HardTycoons control screen.
- Session block counter and area display.

## Build

Requirements: JDK 21 and Gradle 8.10+ (or use a Gradle wrapper generated for your environment).

```bash
gradle build
```

The mod JAR will be at `build/libs/hardtycoons-1.0.0.jar`.

## Important notes

- This is a clean new project, not a binary patch of HardTycoons 0.9.53.
- This starter build currently implements the selected-area Prison Miner and a basic control screen. The other modules from the old JAR have not yet been ported.
- Use automation only on servers where it is permitted. Server-side anti-cheat and server rules remain authoritative.
- If the server blocks automated mining or the normal client interaction cannot reach a block, the miner will not bypass those restrictions.
