package fr.anonymous.hardtycoons;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class HardTycoonsScreen extends Screen {
    public HardTycoonsScreen() {
        super(Text.literal("HardTycoons Control Center"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 100;
        int top = this.height / 2 - 45;
        addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                Text.literal(PrisonMiner.isEnabled() ? "Pause Prison Miner" : "Start Prison Miner"),
                button -> PrisonMiner.toggle(client))
                .dimensions(left, top, 200, 20).build());
        addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                Text.literal("Reset mining statistics"),
                button -> PrisonMiner.resetStats())
                .dimensions(left, top + 26, 200, 20).build());
        addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                Text.literal("Close"),
                button -> close())
                .dimensions(left, top + 52, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title,
                width / 2, height / 2 - 78, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Blocks mined this session: " + PrisonMiner.getMinedBlocks()),
                width / 2, height / 2 - 57, 0xA8D8FF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Corner A: " + (PrisonMiner.getCornerA() == null
                        ? "not set" : PrisonMiner.getCornerA().toShortString())),
                width / 2, height / 2 + 91, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Corner B: " + (PrisonMiner.getCornerB() == null
                        ? "not set" : PrisonMiner.getCornerB().toShortString())),
                width / 2, height / 2 + 105, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
}
