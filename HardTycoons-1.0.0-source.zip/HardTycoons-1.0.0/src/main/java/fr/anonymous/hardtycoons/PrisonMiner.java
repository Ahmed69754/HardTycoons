package fr.anonymous.hardtycoons;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockState;

import java.util.Comparator;\nimport java.util.stream.StreamSupport;

public final class PrisonMiner {
    private static BlockPos cornerA;
    private static BlockPos cornerB;
    private static BlockPos currentTarget;
    private static boolean enabled;
    private static int tickDelay;
    private static long minedBlocks;
    private static final int MAX_AREA_BLOCKS = 32 * 32 * 16;
    private static final double MAX_REACH_SQUARED = 25.0;

    private PrisonMiner() {}

    public static void selectCorner(MinecraftClient client, boolean first) {
        if (client.player == null || client.world == null) return;
        if (!(client.crosshairTarget instanceof BlockHitResult hit)
                || hit.getType() != HitResult.Type.BLOCK) {
            client.player.sendMessage(Text.literal("§cLook at a block to select a corner."), true);
            return;
        }
        BlockPos selected = hit.getBlockPos().toImmutable();
        if (first) cornerA = selected; else cornerB = selected;
        client.player.sendMessage(Text.literal((first ? "§aCorner A: " : "§bCorner B: ")
                + selected.toShortString()), true);
        validateArea(client.player);
    }

    public static void toggle(MinecraftClient client) {
        if (client.player == null) return;
        if (!hasValidArea()) {
            client.player.sendMessage(Text.literal("§cSelect both corners first (J and K)."), true);
            return;
        }
        enabled = !enabled;
        currentTarget = null;
        client.player.sendMessage(Text.literal(enabled
                ? "§aPrison Miner enabled. L to pause."
                : "§ePrison Miner paused."), true);
    }

    public static void tick(MinecraftClient client) {
        if (!enabled || client.player == null || client.world == null
                || client.interactionManager == null || client.currentScreen != null) return;

        ClientPlayerEntity player = client.player;
        if (player.isSpectator() || player.isCreative()) {
            pause(client, "Miner paused: use Survival or Adventure mode.");
            return;
        }
        if (!hasValidArea()) {
            pause(client, "Miner paused: mining area is not configured.");
            return;
        }
        if (player.getInventory().getEmptySlot() == -1) {
            pause(client, "Inventory full. Clear space, then press L to resume.");
            return;
        }

        if (tickDelay > 0) {
            tickDelay--;
            return;
        }

        if (currentTarget == null || !isMineable(client, currentTarget)
                || !inReach(player, currentTarget)) {
            currentTarget = findNextTarget(client);
            if (currentTarget == null) {
                tickDelay = 10;
                return;
            }
            client.interactionManager.attackBlock(currentTarget, Direction.UP);
        } else {
            boolean stillBreaking = client.interactionManager
                    .updateBlockBreakingProgress(currentTarget, Direction.UP);
            if (!stillBreaking || client.world.getBlockState(currentTarget).isAir()) {
                currentTarget = null;
                minedBlocks++;
                tickDelay = 2;
            }
        }
    }

    private static BlockPos findNextTarget(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        BlockPos min = new BlockPos(
                Math.min(cornerA.getX(), cornerB.getX()),
                Math.min(cornerA.getY(), cornerB.getY()),
                Math.min(cornerA.getZ(), cornerB.getZ()));
        BlockPos max = new BlockPos(
                Math.max(cornerA.getX(), cornerB.getX()),
                Math.max(cornerA.getY(), cornerB.getY()),
                Math.max(cornerA.getZ(), cornerB.getZ()));

        return StreamSupport.stream(BlockPos.iterate(min, max).spliterator(), false)
                .filter(pos -> isMineable(client, pos))
                .filter(pos -> inReach(player, pos))
                .min(Comparator.comparingDouble(pos -> player.squaredDistanceTo(
                        Vec3d.ofCenter(pos))))
                .map(BlockPos::toImmutable)
                .orElse(null);
    }

    private static boolean isMineable(MinecraftClient client, BlockPos pos) {
        if (client.world == null || !insideArea(pos)) return false;
        BlockState state = client.world.getBlockState(pos);
        return !state.isAir() && !state.isLiquid() && state.getHardness(client.world, pos) >= 0
                && !state.hasBlockEntity();
    }

    private static boolean inReach(ClientPlayerEntity player, BlockPos pos) {
        return player.squaredDistanceTo(Vec3d.ofCenter(pos)) <= MAX_REACH_SQUARED;
    }

    private static boolean insideArea(BlockPos pos) {
        return hasValidArea()
                && pos.getX() >= Math.min(cornerA.getX(), cornerB.getX())
                && pos.getX() <= Math.max(cornerA.getX(), cornerB.getX())
                && pos.getY() >= Math.min(cornerA.getY(), cornerB.getY())
                && pos.getY() <= Math.max(cornerA.getY(), cornerB.getY())
                && pos.getZ() >= Math.min(cornerA.getZ(), cornerB.getZ())
                && pos.getZ() <= Math.max(cornerA.getZ(), cornerB.getZ());
    }

    private static boolean hasValidArea() {
        if (cornerA == null || cornerB == null) return false;
        long x = Math.abs(cornerA.getX() - cornerB.getX()) + 1L;
        long y = Math.abs(cornerA.getY() - cornerB.getY()) + 1L;
        long z = Math.abs(cornerA.getZ() - cornerB.getZ()) + 1L;
        return x * y * z <= MAX_AREA_BLOCKS;
    }

    private static void validateArea(ClientPlayerEntity player) {
        if (cornerA != null && cornerB != null && !hasValidArea()) {
            enabled = false;
            player.sendMessage(Text.literal("§cArea too large. Maximum: 32 x 32 x 16 blocks."), true);
        }
    }

    private static void pause(MinecraftClient client, String reason) {
        enabled = false;
        currentTarget = null;
        if (client.player != null) client.player.sendMessage(Text.literal("§e" + reason), true);
    }

    public static boolean isEnabled() { return enabled; }
    public static BlockPos getCornerA() { return cornerA; }
    public static BlockPos getCornerB() { return cornerB; }
    public static long getMinedBlocks() { return minedBlocks; }
    public static void resetStats() { minedBlocks = 0; }
}
