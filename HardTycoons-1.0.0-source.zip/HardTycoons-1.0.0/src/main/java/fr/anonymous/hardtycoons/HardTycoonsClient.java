package fr.anonymous.hardtycoons;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class HardTycoonsClient implements ClientModInitializer {
    private static KeyBinding pos1Key;
    private static KeyBinding pos2Key;
    private static KeyBinding toggleKey;
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        pos1Key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hardtycoons.pos1", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J,
                KeyBinding.Category.MISC));
        pos2Key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hardtycoons.pos2", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K,
                KeyBinding.Category.MISC));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hardtycoons.toggle_miner", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L,
                KeyBinding.Category.MISC));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hardtycoons.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (pos1Key.wasPressed()) PrisonMiner.selectCorner(client, true);
            while (pos2Key.wasPressed()) PrisonMiner.selectCorner(client, false);
            while (toggleKey.wasPressed()) PrisonMiner.toggle(client);
            while (menuKey.wasPressed()) {
                if (client.player != null) client.setScreen(new HardTycoonsScreen());
            }
            PrisonMiner.tick(client);
        });
    }
}
